---
name: Documentation Improvement
about: Report wrong or missing documentation.
title: 'DOC:'
labels: ''
assignees: ''

---

#### Location of the documentation

[this should provide the location of the documentation, e.g. "CONTRIBUTION.md" or the URL of the documentation, e.g. "https://github.com/tangyoha/telegram_media_downloader/blob/master/CONTRIBUTING.md"]

#### Documentation problem

[this should provide a description of what documentation you believe needs to be fixed/improved]

#### Suggested fix for documentation

[this should explain the suggested fix and **why** it's better than the existing documentation]
