from module.filter import Filter

Filter()
