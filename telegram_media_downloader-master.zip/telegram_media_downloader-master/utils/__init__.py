"""Init namespace"""

__version__ = "2.2.4"
__license__ = "MIT License"
__copyright__ = "Copyright (C) 2024 tangyoha <https://github.com/tangyoha>"
